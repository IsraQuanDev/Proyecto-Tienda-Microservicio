package com.mx.MsEmpleados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEmpleadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
