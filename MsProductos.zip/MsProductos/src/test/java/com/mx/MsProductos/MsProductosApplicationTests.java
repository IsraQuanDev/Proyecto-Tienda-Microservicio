package com.mx.MsProductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
